import socket

header = 16
port = 5050
server = socket.gethostbyname(socket.gethostname())
addr = (server, port)
format = "utf-8"
disconnect_message = "End"

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(addr)

server.listen()
print("Server is listening")
conn, addr = server.accept()
connected = True

while connected:
    msg_length = conn.recv(header).decode(format)
    if msg_length:
        msg_length = int(msg_length)
        msg = conn.recv(msg_length).decode(format)
        if msg == disconnect_message:
            connected = False
            conn.send("Goodbye".encode(format))
        else:
            print(msg)
            conn.send("Message Received".encode(format))
conn.close()
